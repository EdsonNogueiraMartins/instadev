module.exports = {
  up: async (queryInterface, Sequelize) => {
    try {
      console.log('Iniciando migração "up"');
      await queryInterface.createTable('users', {
        id: {
          allowNull: false,
          autoIncrement: true,
          primaryKey: true,
          type: Sequelize.INTEGER,
        },
        name: {
          type: Sequelize.STRING,
          allowNull: false,
        },
        user_name: {
          type: Sequelize.STRING,
          allowNull: false,
          unique: true,
        },
        email: {
          type: Sequelize.STRING,
          allowNull: false,
          unique: true,
        },
        avatar: {
          type: Sequelize.STRING,
        },
        bio: {
          type: Sequelize.STRING,
        },
        gender: {
          type: Sequelize.STRING,
        },
        password_hash: {
          type: Sequelize.STRING,
          allowNull: false,
        },
        created_at: {
          type: Sequelize.DATE,
          allowNull: false,
        },
        updated_at: {
          type: Sequelize.DATE,
          allowNull: false,
        },
      }); 
      console.log('Migração "up" concluída com sucesso');
    } catch (error) {
      console.error('Erro durante migração "up":', error);
      throw error;
    } 
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('users');    
  },
};
