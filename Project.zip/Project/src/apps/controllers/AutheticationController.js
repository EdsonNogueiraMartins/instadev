const jwt = require('jsonwebtoken');
//const { Op } = require('sequelize');
const Users = require('../models/Users');
const { hash } = require('bcryptjs');
const {encrypt} = require('../../utils/crypt');

class AutheticationController {
    async autheticate(req, res) {
        const {email, user_name, password} = req.body;

        const whereClause = { } // password_hash: password
        if(email){
            whereClause.email = email;
        }else if(user_name){
            whereClause.user_name = user_name;
        }else{
            return res.status(401).json({ error: 'we need a e-mail or username!' });    
        }

        const user = await Users.findOne({
            where: whereClause,
        });

        if (!user) {
            return res.status(401).json({ error: 'User not found!' });
        }

        if (!await user.checkPassword(password)) {
            return res.status(401).json({ error: 'Password does not match!' });
        }

        const {id, user_name: userName} = user;

        const {iv, content} = encrypt(id);

        const newId = `${iv}:${content}`;

        const token = jwt.sign({userID: newId}, process.env.HASH_BCRYPT, {
            expiresIn: process.env.EXPIRE_IN,
        });

        return res.status(200).json({ user: {id, user_name: userName}, token: token });
    }
}

module.exports = new AutheticationController();