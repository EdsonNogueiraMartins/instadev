const { Router } = require('express');
const schemaValidator = require('./apps/middlewares/schemaValidator');

const AutheticationMiddleware = require('./apps/middlewares/authentication');

const AutheticationController = require('./apps/controllers/AutheticationController');
const UserController = require('./apps/controllers/UserController');

const userSchema = require('./schema/create.user.schema.json');
const authSchema = require('./schema/auth.schema.json');

const routes = new Router();

routes.post('/user', schemaValidator(userSchema), UserController.create);

routes.post('/auth', schemaValidator(authSchema), AutheticationController.autheticate);

routes.get('/health', (req, res) => res.send({
    message: 'Connected with success!',
}));

routes.use(AutheticationMiddleware);

routes.put('/user', UserController.update);

routes.delete('/user', UserController.delete);

routes.get('/user-profile', UserController.userProfile);

module.exports = routes;